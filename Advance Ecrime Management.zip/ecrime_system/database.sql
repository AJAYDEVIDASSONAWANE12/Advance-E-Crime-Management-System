-- 1. Create the new database
CREATE DATABASE IF NOT EXISTS crime_matrix_db;
USE crime_matrix_db;

-- 2. Create Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'sho', 'cid') NOT NULL,
    full_name VARCHAR(100),
    specialization VARCHAR(100) DEFAULT NULL -- Only for CID
);

-- 3. Create Crimes Table
CREATE TABLE IF NOT EXISTS crimes (
    crime_id VARCHAR(20) PRIMARY KEY, -- Example: CR-4921
    victim_name VARCHAR(100),
    crime_type VARCHAR(50),
    crime_date DATE,
    description TEXT,
    status ENUM('Pending', 'Investigation', 'Solved', 'Closed') DEFAULT 'Pending',
    assigned_to INT NULL, -- Links to User ID (CID)
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL
);

-- 4. Create Logs/Timeline Table
CREATE TABLE IF NOT EXISTS crime_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    crime_id VARCHAR(20),
    log_msg TEXT,
    log_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (crime_id) REFERENCES crimes(crime_id) ON DELETE CASCADE
);

-- 5. Insert Default Admin (Optional, as PHP script also does this)
-- Password is 'admin123'
INSERT INTO users (username, password, role, full_name) 
VALUES ('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'System Administrator');

USE crime_matrix_db;

-- 1. Table for Anonymous Tips
CREATE TABLE IF NOT EXISTS tips (
    id INT AUTO_INCREMENT PRIMARY KEY,
    location VARCHAR(100),
    detail TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Table for Wanted Criminals
CREATE TABLE IF NOT EXISTS wanted (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    crime VARCHAR(100),
    reward VARCHAR(50)
);

-- Insert dummy wanted criminals
INSERT INTO wanted (name, crime, reward) VALUES 
('Kaal Bhairav', 'Bank Robbery', '$50,000'),
('Don John', 'Cyber Hacking', '$10,000');