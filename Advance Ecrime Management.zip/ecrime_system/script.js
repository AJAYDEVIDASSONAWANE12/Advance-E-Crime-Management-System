// HELPER: Send Data to API
async function postData(url = '', data = {}) {
    const formData = new FormData();
    for (const key in data) formData.append(key, data[key]);
    
    const response = await fetch(url, { method: 'POST', body: formData });
    return response.json();
}

// 1. LOGIN LOGIC
const loginForm = document.getElementById('loginForm');
if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const data = Object.fromEntries(new FormData(loginForm));
        data.action = 'login';
        
        const res = await postData('api.php', data);
        if (res.status === 'success') {
            window.location.href = 'dashboard.php';
        } else {
            document.getElementById('loginMsg').innerText = res.message;
            document.getElementById('loginMsg').style.color = 'red';
        }
    });
}

// 2. CRIME TRACKING LOGIC
const trackForm = document.getElementById('trackForm');
if (trackForm) {
    trackForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const id = document.getElementById('track_id').value;
        const res = await postData('api.php', { action: 'track_crime', crime_id: id });
        
        const resultBox = document.getElementById('trackResult');
        resultBox.classList.remove('hidden');
        
        if (res.status === 'success') {
            let logsHtml = res.logs.map(l => `<li><small>${l.log_date}</small>: ${l.status_message}</li>`).join('');
            resultBox.innerHTML = `
                <h3>Status: <span style="color:blue">${res.data.status}</span></h3>
                <p><strong>Officer in Charge:</strong> ${res.data.officer_name || 'Not Assigned'}</p>
                <hr>
                <h4>Timeline:</h4>
                <ul>${logsHtml}</ul>
            `;
        } else {
            resultBox.innerHTML = `<p style="color:red">Case not found.</p>`;
        }
    });
}

// 3. ADMIN: ADD STAFF
const staffForm = document.getElementById('addStaffForm');
if (staffForm) {
    staffForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const data = Object.fromEntries(new FormData(staffForm));
        const res = await postData('api.php', data);
        if(res.status === 'success') alert('Staff Added!');
        else alert(res.message);
    });
}

// 4. SHO: REGISTER CRIME
const crimeForm = document.getElementById('crimeForm');
if (crimeForm) {
    crimeForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const data = Object.fromEntries(new FormData(crimeForm));
        const res = await postData('api.php', data);
        if(res.status === 'success') {
            alert('Crime Registered! ID: ' + res.crime_id);
            location.reload();
        }
    });
}

// 5. CID: UPDATE STATUS
async function updateStatus(e) {
    e.preventDefault();
    const form = e.target;
    const data = Object.fromEntries(new FormData(form));
    const res = await postData('api.php', data);
    if(res.status === 'success') {
        alert('Status Updated');
        location.reload();
    }
}