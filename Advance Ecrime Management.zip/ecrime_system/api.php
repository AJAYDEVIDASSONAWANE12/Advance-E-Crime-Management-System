<?php
session_start();
require 'db_connect.php';
header('Content-Type: application/json');

$action = $_POST['action'] ?? '';

// 1. LOGIN
if ($action === 'login') {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$_POST['username']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($_POST['password'], $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['name'] = $user['full_name'];
        echo json_encode(['status' => 'success', 'role' => $user['role']]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid credentials']);
    }
    exit;
}

// 2. PUBLIC TRACKING
if ($action === 'track_crime') {
    $stmt = $pdo->prepare("SELECT c.*, u.full_name as officer_name FROM crimes c LEFT JOIN users u ON c.assigned_to = u.id WHERE crime_id = ?");
    $stmt->execute([$_POST['crime_id']]);
    $crime = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Fetch logs
    $logStmt = $pdo->prepare("SELECT * FROM case_logs WHERE crime_id = ? ORDER BY log_date DESC");
    $logStmt->execute([$_POST['crime_id']]);
    $logs = $logStmt->fetchAll(PDO::FETCH_ASSOC);

    if ($crime) {
        echo json_encode(['status' => 'success', 'data' => $crime, 'logs' => $logs]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Crime ID not found']);
    }
    exit;
}

// --- PROTECTED ROUTES (REQUIRE LOGIN) ---
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

// 3. ADMIN: ADD STAFF
if ($action === 'add_staff' && $_SESSION['role'] === 'admin') {
    $passHash = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO users (username, password, role, full_name, specialization) VALUES (?, ?, ?, ?, ?)");
    try {
        $stmt->execute([$_POST['username'], $passHash, $_POST['role'], $_POST['fullname'], $_POST['spec']]);
        echo json_encode(['status' => 'success']);
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => 'Username already exists']);
    }
    exit;
}

// 4. SHO: REGISTER CRIME
if ($action === 'register_crime' && $_SESSION['role'] === 'sho') {
    // Generate Unique ID: CRM-TIMESTAMP-RAND
    $crimeId = 'CRM-' . date('Ymd') . '-' . rand(100, 999);
    
    $stmt = $pdo->prepare("INSERT INTO crimes (crime_id, victim_name, victim_age, victim_edu, crime_type, crime_date, description, location, registered_by, assigned_to) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $crimeId, $_POST['v_name'], $_POST['v_age'], $_POST['v_edu'], 
        $_POST['c_type'], $_POST['c_date'], $_POST['desc'], $_POST['loc'], 
        $_SESSION['user_id'], $_POST['assign_cid']
    ]);

    // Add Initial Log
    $logStmt = $pdo->prepare("INSERT INTO case_logs (crime_id, updated_by, status_message) VALUES (?, ?, ?)");
    $logStmt->execute([$crimeId, $_SESSION['user_id'], "Case Registered and Assigned to Officer."]);

    echo json_encode(['status' => 'success', 'crime_id' => $crimeId]);
    exit;
}

// 5. CID: UPDATE STATUS
if ($action === 'update_status' && $_SESSION['role'] === 'cid') {
    $stmt = $pdo->prepare("UPDATE crimes SET status = ? WHERE crime_id = ? AND assigned_to = ?");
    $stmt->execute([$_POST['status'], $_POST['crime_id'], $_SESSION['user_id']]);

    // Add Log
    $logStmt = $pdo->prepare("INSERT INTO case_logs (crime_id, updated_by, status_message) VALUES (?, ?, ?)");
    $logStmt->execute([$_POST['crime_id'], $_SESSION['user_id'], "Status updated to " . $_POST['status'] . ": " . $_POST['remarks']]);

    echo json_encode(['status' => 'success']);
    exit;
}
?>