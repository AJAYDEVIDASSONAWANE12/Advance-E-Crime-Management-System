<?php
session_start();
require 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$role = $_SESSION['role'];
$userId = $_SESSION['user_id'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Dashboard - <?php echo ucfirst($role); ?></title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <nav>
        <h3>E-Crime Dashboard (<?php echo ucfirst($role); ?>)</h3>
        <a href="index.php?logout=true" class="logout-btn">Logout</a>
    </nav>

    <div class="dashboard-container">
        
        <?php if ($role === 'admin'): ?>
        <div class="panel">
            <h2>Add New Staff</h2>
            <form id="addStaffForm">
                <input type="hidden" name="action" value="add_staff">
                <select name="role" required>
                    <option value="sho">SHO</option>
                    <option value="cid">CID Officer</option>
                </select>
                <input type="text" name="fullname" placeholder="Full Name" required>
                <input type="text" name="username" placeholder="Username" required>
                <input type="password" name="password" placeholder="Password" required>
                <input type="text" name="spec" placeholder="Specialization (CID Only)">
                <button type="submit">Create User</button>
            </form>
            <div id="adminMsg"></div>
        </div>
        <?php endif; ?>

        <?php if ($role === 'sho'): ?>
        <div class="panel">
            <h2>📝 Register New Crime</h2>
            <form id="crimeForm">
                <input type="hidden" name="action" value="register_crime">
                <div class="grid-form">
                    <input type="text" name="v_name" placeholder="Victim Name" required>
                    <input type="number" name="v_age" placeholder="Age" required>
                    <input type="text" name="v_edu" placeholder="Education">
                    <select name="c_type" id="crimeType" required>
                        <option value="">Select Crime Type</option>
                        <option value="Robbery">Robbery</option>
                        <option value="Cyber">Cyber Crime</option>
                        <option value="Homicide">Homicide</option>
                        <option value="Assault">Assault</option>
                    </select>
                    <input type="date" name="c_date" required>
                    <input type="text" name="loc" placeholder="Location" required>
                </div>
                <textarea name="desc" placeholder="Crime Details..." required></textarea>
                
                <label>Assign CID Officer:</label>
                <select name="assign_cid" required>
                    <?php
                    // Fetch only CID officers
                    $cids = $pdo->query("SELECT * FROM users WHERE role = 'cid'")->fetchAll();
                    foreach ($cids as $cid) {
                        echo "<option value='{$cid['id']}'>{$cid['full_name']} ({$cid['specialization']})</option>";
                    }
                    ?>
                </select>
                <button type="submit">Register & Assign</button>
            </form>
        </div>

        <div class="panel mt-20">
            <h2>Station Crime Log</h2>
            <table>
                <thead><tr><th>ID</th><th>Type</th><th>Assigned To</th><th>Status</th></tr></thead>
                <tbody>
                    <?php
                    $crimes = $pdo->query("SELECT c.*, u.full_name FROM crimes c LEFT JOIN users u ON c.assigned_to = u.id ORDER BY created_at DESC")->fetchAll();
                    foreach ($crimes as $c) {
                        echo "<tr><td>{$c['crime_id']}</td><td>{$c['crime_type']}</td><td>{$c['full_name']}</td><td><span class='badge {$c['status']}'>{$c['status']}</span></td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>

        <?php if ($role === 'cid'): ?>
        <div class="panel">
            <h2>🕵️ My Assigned Cases</h2>
            <div class="cases-grid">
                <?php
                $myCases = $pdo->prepare("SELECT * FROM crimes WHERE assigned_to = ? AND status != 'Closed'");
                $myCases->execute([$userId]);
                while ($case = $myCases->fetch()) {
                ?>
                <div class="case-card">
                    <h4><?php echo $case['crime_id']; ?> - <?php echo $case['crime_type']; ?></h4>
                    <p><?php echo $case['description']; ?></p>
                    <p><strong>Victim:</strong> <?php echo $case['victim_name']; ?></p>
                    <form class="statusForm" onsubmit="updateStatus(event)">
                        <input type="hidden" name="action" value="update_status">
                        <input type="hidden" name="crime_id" value="<?php echo $case['crime_id']; ?>">
                        <select name="status">
                            <option value="Investigation">Investigation</option>
                            <option value="Solved">Solved</option>
                            <option value="Closed">Closed</option>
                        </select>
                        <input type="text" name="remarks" placeholder="Update Remarks" required>
                        <button type="submit">Update</button>
                    </form>
                </div>
                <?php } ?>
            </div>
        </div>
        <?php endif; ?>

    </div>
    <script src="script.js"></script>
</body>
</html>