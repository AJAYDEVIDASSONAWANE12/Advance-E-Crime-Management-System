SSBT COET JALGAON  DEVELOPER NAME  "AJAY DEVIDAS SONAWANE".
<?php
session_start();

// ==========================================
// 1. DATABASE CONNECTION
// ==========================================
$host = 'localhost';
$db   = 'crime_matrix_db';
$user = 'root';
$pass = ''; 

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) { die("DB Error: " . $e->getMessage()); }

// Auto-Create Admin if missing
if ($pdo->query("SELECT count(*) FROM users WHERE username='admin'")->fetchColumn() == 0) {
    $hash = password_hash('admin123', PASSWORD_DEFAULT);
    $pdo->prepare("INSERT INTO users (username, password, role, full_name) VALUES ('admin', ?, 'admin', 'Super Admin')")->execute([$hash]);
}

// ==========================================
// 2. AJAX API (HANDLES TRACKING)
// ==========================================
if (isset($_POST['action']) && $_POST['action'] === 'track_crime') {
    header('Content-Type: application/json');
    
    $stmt = $pdo->prepare("SELECT c.*, u.full_name as officer FROM crimes c LEFT JOIN users u ON c.assigned_to = u.id WHERE crime_id = ?");
    $stmt->execute([$_POST['crime_id']]);
    $crime = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($crime) {
        echo json_encode(['status' => 'success', 'data' => $crime]);
    } else {
        echo json_encode(['status' => 'error']);
    }
    exit; // Stop script here so HTML doesn't load
}

// ==========================================
// 3. BACKEND FORM ACTIONS
// ==========================================
$msg = "";
$receipt_data = null; 

// ANALYTICS DATA
$chartData = []; $chartLabels = [];
if(isset($_SESSION['role']) && in_array($_SESSION['role'], ['admin', 'sho'])) {
    $stmt = $pdo->query("SELECT crime_type, COUNT(*) as count FROM crimes GROUP BY crime_type");
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        $chartLabels[] = $row['crime_type'];
        $chartData[] = $row['count'];
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['action'])) {
    
    // LOGIN
    if (isset($_POST['login'])) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$_POST['username']]);
        $u = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($u && password_verify($_POST['password'], $u['password'])) {
            $_SESSION['user_id'] = $u['id']; $_SESSION['role'] = $u['role']; $_SESSION['name'] = $u['full_name'];
            header("Location: index.php"); exit;
        } else { $msg = "❌ Invalid Credentials"; }
    }

    // LOGOUT
    if (isset($_POST['logout'])) { session_destroy(); header("Location: index.php"); exit; }

    // SHO: REGISTER CRIME
    if (isset($_POST['reg_crime'])) {
        $cid = 'CRM-' . date('y') . '-' . rand(1000, 9999);
        $pdo->prepare("INSERT INTO crimes (crime_id, victim_name, crime_type, crime_date, description, assigned_to) VALUES (?,?,?,?,?,?)")
            ->execute([$cid, $_POST['vname'], $_POST['ctype'], $_POST['cdate'], $_POST['desc'], $_POST['assign']]);
        
        $receipt_data = ['id' => $cid, 'name' => $_POST['vname'], 'type' => $_POST['ctype'], 'date' => $_POST['cdate'], 'desc' => $_POST['desc']];
        $msg = "✅ Crime Registered! Print Receipt.";
    }

    // ADMIN: ADD STAFF
    if (isset($_POST['add_staff'])) {
        try {
            $pdo->prepare("INSERT INTO users (username, password, role, full_name, specialization) VALUES (?,?,?,?,?)")
                ->execute([$_POST['uname'], password_hash($_POST['pass'], PASSWORD_DEFAULT), $_POST['role'], $_POST['fname'], $_POST['spec']]);
            $msg = "✅ Staff Added!";
        } catch (Exception $e) { $msg = "❌ Username exists!"; }
    }
    
    // CID: UPDATE STATUS
    if (isset($_POST['update_status'])) {
        $pdo->prepare("UPDATE crimes SET status = ? WHERE crime_id = ?")->execute([$_POST['status'], $_POST['cid']]);
        $msg = "✅ Status Updated!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crime Matrix System</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        :root { --primary: #0f172a; --sec: rgba(30, 41, 59, 0.9); --accent: #38bdf8; --text: #f1f5f9; }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', sans-serif; }
        
        /* MODIFIED BODY BACKGROUND */
        body { 
            background: linear-gradient(rgba(15, 23, 42, 0.9), rgba(15, 23, 42, 0.95)), url('https://images.unsplash.com/photo-1478760329108-5c3ed9d495a0?q=80&w=2074&auto=format&fit=crop');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            color: var(--text); 
            padding-bottom: 50px; 
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        /* UI COMPONENTS */
        nav { background: var(--sec); padding: 15px 30px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #334155; position: sticky; top: 0; z-index: 100; backdrop-filter: blur(10px); }
        .logo { font-size: 1.5rem; font-weight: bold; color: var(--accent); }
        .nav-btn { background: var(--accent); color: var(--primary); padding: 8px 20px; border-radius: 20px; border: none; cursor: pointer; font-weight: bold; }
        .nav-btn.logout { background: #ef4444; color: white; }
        
        .container { max-width: 1100px; margin: 30px auto; padding: 0 20px; flex: 1; }
        .card { background: var(--sec); padding: 25px; border-radius: 12px; margin-bottom: 25px; border: 1px solid #334155; box-shadow: 0 4px 6px rgba(0,0,0,0.3); }
        h2 { border-bottom: 2px solid var(--accent); padding-bottom: 10px; margin-bottom: 20px; color: var(--accent); }
        
        input, select, textarea { width: 100%; padding: 12px; margin: 8px 0; background: var(--primary); border: 1px solid #475569; color: white; border-radius: 6px; }
        button.submit-btn { width: 100%; padding: 12px; background: var(--accent); color: var(--primary); font-weight: bold; border: none; border-radius: 6px; cursor: pointer; margin-top: 10px; transition: 0.3s; }
        button.submit-btn:hover { box-shadow: 0 0 15px var(--accent); }
        
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #334155; }
        th { color: #94a3b8; }
        .badge { padding: 4px 10px; border-radius: 12px; font-size: 0.8em; font-weight: bold; }
        .Solved { background: #22c55e; color: black; }
        .Pending { background: #eab308; color: black; }
        .Investigation { background: #3b82f6; color: white; }
        
        /* DEVELOPER CREDIT STYLES */
        .dev-footer {
            text-align: center;
            padding: 20px;
            margin-top: auto;
            border-top: 1px solid #334155;
            background: rgba(15, 23, 42, 0.95);
        }
        .dev-text {
            color: #94a3b8;
            font-size: 0.9rem;
            letter-spacing: 1px;
        }
        .dev-name {
            font-family: 'Courier New', monospace;
            color: var(--accent);
            font-weight: bold;
            font-size: 1.1rem;
            text-transform: uppercase;
            margin-left: 10px;
            padding: 5px 12px;
            border: 1px solid var(--accent);
            border-radius: 4px;
            box-shadow: 0 0 10px rgba(56, 189, 248, 0.2);
            text-shadow: 0 0 5px var(--accent);
            background: rgba(56, 189, 248, 0.05);
            display: inline-block;
        }

        /* MODALS & PRINT */
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); z-index: 1000; align-items: center; justify-content: center; backdrop-filter: blur(5px); }
        .modal-content { background: var(--primary); padding: 30px; border-radius: 15px; width: 100%; max-width: 400px; position: relative; border: 1px solid var(--accent); }
        .close { position: absolute; top: 15px; right: 20px; font-size: 24px; cursor: pointer; color:white; }
        
        @media print {
            body * { visibility: hidden; }
            #receiptModal, #receiptModal * { visibility: visible; }
            #receiptModal { position: absolute; left: 0; top: 0; width: 100%; height: 100%; background: white; display: block; }
            .modal-content { border: none; box-shadow: none; max-width: 100%; color: black; }
            .print-hide { display: none; }
        }
    </style>
</head>
<body>

    <nav>
        <div class="logo"><i class="fas fa-shield-alt"></i> CRIME MATRIX</div>
        <div>
            <?php if(isset($_SESSION['user_id'])): ?>
                <span style="margin-right: 15px; color:#94a3b8;">User: <b><?php echo $_SESSION['name']; ?></b></span>
                <form method="POST" style="display:inline;"><button type="submit" name="logout" class="nav-btn logout">Logout</button></form>
            <?php else: ?>
                <button onclick="document.getElementById('loginModal').style.display='flex'" class="nav-btn">Staff Login</button>
            <?php endif; ?>
        </div>
    </nav>

    <?php if($msg): ?> <div style="background:var(--sec); color:var(--accent); text-align:center; padding:15px; border-bottom:1px solid #334155;"><?php echo $msg; ?></div> <?php endif; ?>

    <div class="container">

        <?php if(!isset($_SESSION['user_id'])): ?>
        <div style="text-align: center; padding: 50px 0;">
            <h1 style="font-size: 3rem; margin-bottom: 20px; text-shadow: 0 0 20px rgba(0,0,0,0.5);">Public Crime Tracker</h1>
            <div class="card" style="max-width: 600px; margin: 0 auto;">
                <h2><i class="fas fa-search"></i> Check Case Status</h2>
                <input type="text" id="trackInput" placeholder="Enter Crime ID (e.g. CRM-26-1234)">
                <button onclick="trackCrime()" class="submit-btn">Search Record</button>
                
                <div id="trackResult" style="display:none; text-align:left; margin-top:20px; padding-top:20px; border-top:1px solid #334155;">
                    <div style="background: #0f172a; padding: 15px; border-radius: 8px;">
                        <h3 id="resId" style="color:white; margin-bottom:5px;"></h3>
                        <p style="color:#94a3b8; margin-bottom:10px;">Status: <span id="resStatus" class="badge"></span></p>
                        <p><strong>Officer in Charge:</strong> <span id="resOfficer"></span></p>
                        <p><strong>Type:</strong> <span id="resType"></span></p>
                        <p><strong>Description:</strong> <span id="resDesc"></span></p>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <?php if(isset($_SESSION['role'])): ?>
            
            <?php if(in_array($_SESSION['role'], ['admin', 'sho'])): ?>
            <div style="display:grid; grid-template-columns: 2fr 1fr; gap:20px;">
                <div class="card">
                    <h2>Analytics</h2>
                    <canvas id="crimeChart"></canvas>
                </div>
                <div class="card" style="text-align:center; display:flex; flex-direction:column; justify-content:center;">
                    <h1 style="font-size:4rem; color:var(--accent);"><?php echo array_sum($chartData); ?></h1>
                    <p>Total Crimes Registered</p>
                </div>
            </div>
            <?php endif; ?>

            <?php if($_SESSION['role'] == 'admin'): ?>
            <div class="card">
                <h2><i class="fas fa-user-plus"></i> Add New Staff</h2>
                <form method="POST">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <input type="text" name="fname" placeholder="Full Name" required>
                        <select name="role" required>
                            <option value="sho">Station House Officer (SHO)</option>
                            <option value="cid">CID Investigator</option>
                        </select>
                        <input type="text" name="uname" placeholder="Username" required>
                        <input type="password" name="pass" placeholder="Password" required>
                    </div>
                    <input type="text" name="spec" placeholder="Specialization (CID Only)">
                    <button type="submit" name="add_staff" class="submit-btn">Create Account</button>
                </form>
            </div>

            <div class="card">
                <h2><i class="fas fa-users"></i> Police Staff Directory</h2>
                <table>
                    <thead><tr><th>Name</th><th>Role</th><th>Username</th><th>Specialization</th></tr></thead>
                    <tbody>
                    <?php
                    $staff = $pdo->query("SELECT * FROM users WHERE role != 'admin' ORDER BY id DESC");
                    while($s = $staff->fetch()): ?>
                        <tr>
                            <td><?php echo $s['full_name']; ?></td>
                            <td><span class="badge" style="background:#475569; color:white;"><?php echo strtoupper($s['role']); ?></span></td>
                            <td><?php echo $s['username']; ?></td>
                            <td><?php echo $s['specialization'] ?: 'N/A'; ?></td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>

            <?php if($_SESSION['role'] == 'sho'): ?>
            <div class="card">
                <h2><i class="fas fa-file-contract"></i> Register Complaint</h2>
                <form method="POST">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <input type="text" name="vname" placeholder="Victim Name" required>
                        <select name="ctype" required>
                            <option value="Theft">Theft</option><option value="Assault">Assault</option>
                            <option value="Cybercrime">Cybercrime</option><option value="Fraud">Fraud</option>
                        </select>
                        <input type="date" name="cdate" required>
                        <select name="assign" required>
                            <option value="">Assign CID Officer</option>
                            <?php
                            $cids = $pdo->query("SELECT * FROM users WHERE role='cid'");
                            while($c = $cids->fetch()){ echo "<option value='{$c['id']}'>{$c['full_name']}</option>"; }
                            ?>
                        </select>
                    </div>
                    <textarea name="desc" placeholder="Details" rows="3" required></textarea>
                    <button type="submit" name="reg_crime" class="submit-btn">Register & Print Receipt</button>
                </form>
            </div>
            <?php endif; ?>

            <?php if($_SESSION['role'] == 'cid'): ?>
            <div class="card">
                <h2><i class="fas fa-briefcase"></i> Assigned Cases</h2>
                <table>
                    <thead><tr><th>ID</th><th>Type</th><th>Status</th><th>Action</th></tr></thead>
                    <tbody>
                    <?php
                    $cases = $pdo->prepare("SELECT * FROM crimes WHERE assigned_to = ? AND status != 'Closed'");
                    $cases->execute([$_SESSION['user_id']]);
                    while($c = $cases->fetch()): ?>
                        <tr>
                            <td><?php echo $c['crime_id']; ?></td>
                            <td><?php echo $c['crime_type']; ?></td>
                            <td><span class="badge <?php echo $c['status']; ?>"><?php echo $c['status']; ?></span></td>
                            <td>
                                <form method="POST" style="display:flex; gap:5px;">
                                    <input type="hidden" name="cid" value="<?php echo $c['crime_id']; ?>">
                                    <select name="status" style="padding:5px;"><option value="Investigation">Investigate</option><option value="Solved">Solved</option><option value="Closed">Closed</option></select>
                                    <button type="submit" name="update_status" class="submit-btn" style="margin:0; width:auto; padding:5px;">Update</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>

        <?php endif; ?>
    </div>

    <div class="dev-footer">
        <span class="dev-text">Designed & Developed By</span>
        <span class="dev-name">AJAY DEVIDAS SONAWANE</span>
    </div>

    <div id="loginModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="document.getElementById('loginModal').style.display='none'">&times;</span>
            <h2 style="text-align:center;">Staff Login</h2>
            <form method="POST">
                <input type="text" name="username" placeholder="Username" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit" name="login" class="submit-btn">Login</button>
            </form>
        </div>
    </div>

    <?php if($receipt_data): ?>
    <div id="receiptModal" class="modal" style="display:flex;">
        <div class="modal-content" style="background:white; color:black;">
            <span class="close print-hide" onclick="document.getElementById('receiptModal').style.display='none'" style="color:black;">&times;</span>
            <div style="border:2px dashed black; padding:20px; font-family:monospace;">
                <h3 style="text-align:center; border-bottom:2px solid black; padding-bottom:10px;">CRIME REGISTRATION SLIP</h3>
                <p><strong>ID:</strong> <?php echo $receipt_data['id']; ?></p>
                <p><strong>Name:</strong> <?php echo $receipt_data['name']; ?></p>
                <p><strong>Type:</strong> <?php echo $receipt_data['type']; ?></p>
                <p><strong>Date:</strong> <?php echo $receipt_data['date']; ?></p>
                <hr>
                <p style="font-size:12px;"><?php echo $receipt_data['desc']; ?></p>
            </div>
            <button onclick="window.print()" class="submit-btn print-hide" style="margin-top:20px; background:#333;">Print</button>
        </div>
    </div>
    <?php endif; ?>

    <script>
        // TRACKING LOGIC (AJAX)
        async function trackCrime() {
            const id = document.getElementById('trackInput').value;
            const resDiv = document.getElementById('trackResult');
            
            if(!id) return alert("Please enter a Crime ID");

            const formData = new FormData();
            formData.append('action', 'track_crime');
            formData.append('crime_id', id);

            try {
                const req = await fetch('index.php', { method: 'POST', body: formData });
                const res = await req.json();

                if(res.status === 'success') {
                    resDiv.style.display = 'block';
                    document.getElementById('resId').innerText = res.data.crime_id;
                    document.getElementById('resStatus').innerText = res.data.status;
                    document.getElementById('resStatus').className = `badge ${res.data.status}`;
                    document.getElementById('resOfficer').innerText = res.data.officer || "Pending Assignment";
                    document.getElementById('resType').innerText = res.data.crime_type;
                    document.getElementById('resDesc').innerText = res.data.description;
                } else {
                    alert("Crime ID not found in database.");
                    resDiv.style.display = 'none';
                }
            } catch(e) { console.error(e); alert("Error connecting to server."); }
        }

        // CHARTS
        <?php if(isset($_SESSION['role']) && in_array($_SESSION['role'], ['admin', 'sho'])): ?>
        new Chart(document.getElementById('crimeChart'), {
            type: 'doughnut',
            data: { labels: <?php echo json_encode($chartLabels); ?>, datasets: [{ data: <?php echo json_encode($chartData); ?>, borderWidth: 0, backgroundColor: ['#ef4444', '#f59e0b', '#3b82f6', '#10b981'] }] },
            options: { responsive: true, plugins: { legend: { position: 'right', labels: { color: 'white' } } } }
        });
        <?php endif; ?>
    </script>
</body>
</html>